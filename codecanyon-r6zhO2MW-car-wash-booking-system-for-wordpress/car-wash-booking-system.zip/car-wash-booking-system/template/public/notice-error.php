
		<div class="cbs-notice cbs-notice-error">
			<?php echo esc_html($this->data['message']); ?>
		</div>