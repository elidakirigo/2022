<?php
		$LogManager=new CBSLogManager();
		echo $LogManager->show('google_calendar');