<?php
		$LogManager=new CBSLogManager();
		echo $LogManager->show('mail');